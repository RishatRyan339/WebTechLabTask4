
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <fieldset>
<legend><h1>PROFILE PICTURE</h1></legend>
<img src="LabTask3.PNG" height="" width=""></img>
<br><button>Choose File</button> No file chosen 
<p>_____________<p>
<button>Submit</button>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  


  <div class="container">
    
  </div>

 

 
</form>

</fieldset>